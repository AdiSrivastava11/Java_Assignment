package com.microservice.aditya.limits_service1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitsService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
