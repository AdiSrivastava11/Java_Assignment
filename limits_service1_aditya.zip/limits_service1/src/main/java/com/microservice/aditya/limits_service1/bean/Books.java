package com.microservice.aditya.limits_service1.bean;

public class Books {
	private String bookName;
	private String authorName;
	
	
	public Books()
	{
		System.out.println("Book bean created..");
	}
	
	
	public Books( String bookName,String authorName) {
		super();
		this.bookName = bookName;
		this.authorName = authorName;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	
	@Override
	public String toString() {
		return "Book [bookName=" + bookName +  ", authorName=" + authorName + "]";
	}


//	@Override
//	public boolean equals(Object obj) {
//		return  this.bookId == ((Books)obj).bookId;
//	}
}
