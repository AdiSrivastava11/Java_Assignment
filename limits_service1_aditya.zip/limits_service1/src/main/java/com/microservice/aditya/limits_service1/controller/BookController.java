package com.microservice.aditya.limits_service1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.aditya.limits_service1.bean.Books;
import com.microservice.aditya.limits_service1.configuration.BookConfiguration;

@RestController
public class BookController {

	@Autowired
	private BookConfiguration bookconfiguration;

	@GetMapping("/Books")
	public Books retrieveBooks() {
		return new Books(bookconfiguration.getBookname(), 
				bookconfiguration.getBookauthor());

	}
}
